"""MCP Demo - A simple MCP server package."""

__version__ = "0.1.4"
__author__ = "yashuashua"
__email__ = "734496997@qq.com"

from .server import main

__all__ = ["main"]